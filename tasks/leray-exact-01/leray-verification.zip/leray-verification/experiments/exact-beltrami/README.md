# Exact periodic Beltrami flow: numerical smoke test

Source of the mathematical case: `contact-symplectic/questions-and-experiments.md` in
[`walnut-burgundy/leray-overlooking-the-seine`](https://github.com/walnut-burgundy/leray-overlooking-the-seine).

**Status:** locally compiled and run. NOT merged into the repository. NOT submitted through
Flexible Pipes and NOT independently accepted by AI-CI. This is a bounded runnable
verification fixture, **not a general 3-D Navier–Stokes solver**.

## Reproduce

```sh
cc -O2 -std=c11 -Wall -Wextra -Werror -pedantic \
    experiments/exact-beltrami/beltrami.c -lm -o /tmp/leray-beltrami
/tmp/leray-beltrami
```

From this bundle's root, the command produces spatial, temporal, combined and
inviscid cases. A failed convergence check or accepted invalid parameter exits
with a nonzero code. `results.txt` contains one local run; it is not an FP receipt.

## Mathematics and discretization

On a flat periodic box with length 2π in each direction,

    u₀(x,y,z) = (sin z, cos z, 0)
    curl u₀ = u₀,   divergence u₀ = 0,   Δu₀ = −u₀,
    (u₀ · ∇)u₀ = 0.

For no forcing, constant pressure, and nondimensional viscosity ν≥0,

    u(t) = e^(−νt) u₀,
    kinetic energy per unit volume = ½e^(−2νt),
    helicity per unit volume = e^(−2νt).

Particles have constant z and horizontal displacement
`[(1 − exp(−νt))/ν] (sin z, cos z)` when ν>0, or `t(sin z, cos z)` when ν=0.

The code stores u_x(z), u_y(z) only. At each time step it applies the centered,
periodic second difference to diffusion, advances by explicit Euler, and uses
trapezoidal integration for particle displacement. For this particular field,
that reduced diffusion equation is an **exact invariant subproblem** of
Navier–Stokes; it does not exercise nonlinear advection, pressure solvers,
wall boundaries, or three-dimensional instability.

## Independent refinement axes

- **Spatial:** N=16,32,64,128; check the centered discrete Laplacian and curl of
  the exact *initial* field. Errors must shrink by approximately 4× per doubling.
- **Temporal:** N=64 fixed; 64,128,256,512 explicit-Euler steps. Compare to the
  **semidiscrete** (spatially discretized, continuous-time) exact decay
  `exp(−ν λₕ t)`, with `λₕ=4 sin²(h/2)/h²`. Errors must shrink by approximately
  2× per doubling. This avoids accidentally mixing time error and space error.
- **Combined:** N=16,32,64,128 and `steps=4N²`; compare simulated velocity,
  energy, helicity and particle displacements with the original continuous
  solution. Relative velocity error should shrink by roughly 4×.
- **Inviscid:** ν=0 preserves this field, energy, and exact particle translation.
- **Failure cases:** unstable explicit-Euler step, fewer than eight spatial
  points, or negative viscosity must be rejected.

Run parameters are ν=0.2 and t=1 for the viscous tests. Velocity is normalized
by the exact velocity amplitude; all integral diagnostics are per unit 3-D
volume. At N=128 the combined-case velocity error is about 3.99×10⁻⁵, and the
observed physical energy density is about 0.335187 versus exact 0.335160.
These numbers are measurements from this implementation, not from a CFD paper.

The discrete helicity is systematically below its continuum counterpart
because the centered discrete curl of the fundamental sine/cosine mode carries
factor `sin(h)/h`. It should **converge**, not be falsely asserted exactly
conserved at finite resolution. The displayed divergence is identically zero
**by the chosen ansatz** and is not evidence that a general solver enforces
incompressibility.

## Intended next work after acceptance

Use this fixture as the smallest numerical stage before implementing the
repo's pressure-gradient invariance test, geometric-structure comparisons,
and smooth NACA0012 baseline. The three separately requested Lockerby packets
(spanwise forcing; resonant microjet; rarefied/slip–R13–DSMC/hybrid) remain
unimplemented. The existing literature and mesh protocols do not amount to
solver results.

All repo writes must be routed through Flexible Pipes and independently gated
by AI-CI. No acceptance or merge is claimed for this local bundle.
